[Project homepage](https://github.com/peter88213/scap_novx) > Instructions for use

---

The scap_novx Python script creates a novelibre project from a Scapple outline.

# Operation

See the [online help](https://peter88213.github.io/nvhelp-en/scap_novx/).
