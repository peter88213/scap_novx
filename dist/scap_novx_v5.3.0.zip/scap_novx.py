"""Scapple to novelibre converter 

usage: scap_novx.py [--silent] Sourcefile

Version 5.3.0
Requires Python 3.6+
Copyright (c) 2025 Peter Triesberger
For further information see https://github.com/peter88213/scap_novx
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)
"""
import os
from pathlib import Path
import sys

from configparser import ConfigParser


class Configuration:

    def __init__(self, settings={}, options={}):
        self.settings = None
        self.options = None
        self._sLabel = 'SETTINGS'
        self._oLabel = 'OPTIONS'
        self.set(settings, options)

    def read(self, iniFile):
        config = ConfigParser()
        config.read(iniFile, encoding='utf-8')
        if config.has_section(self._sLabel):
            section = config[self._sLabel]
            for setting in self.settings:
                fallback = self.settings[setting]
                self.settings[setting] = section.get(setting, fallback)
        if config.has_section(self._oLabel):
            section = config[self._oLabel]
            for option in self.options:
                fallback = self.options[option]
                self.options[option] = section.getboolean(option, fallback)

    def set(self, settings=None, options=None):
        if settings is not None:
            self.settings = settings.copy()
        if options is not None:
            self.options = options.copy()

    def write(self, iniFile):
        config = ConfigParser()
        if self.settings:
            config.add_section(self._sLabel)
            for settingId in self.settings:
                config.set(self._sLabel, settingId, str(self.settings[settingId]))
        if self.options:
            config.add_section(self._oLabel)
            for settingId in self.options:
                if self.options[settingId]:
                    config.set(self._oLabel, settingId, 'Yes')
                else:
                    config.set(self._oLabel, settingId, 'No')
        with open(iniFile, 'w', encoding='utf-8') as f:
            config.write(f)


class Ui:

    def __init__(self, title):
        self.infoWhatText = ''
        self.infoHowText = ''

    def ask_yes_no(self, text):
        return True

    def set_info(self, message):
        self.infoWhatText = message

    def set_status(self, message):
        if message.startswith('!'):
            message = f'Error: {message.split("!", maxsplit=1)[1].strip()}'
        elif message.startswith('#'):
            message = f'Notification: {message.split("#", maxsplit=1)[1].strip()}'
        self.infoHowText = message

    def show_warning(self, message):
        pass

    def start(self):
        pass

import calendar
import gettext
import locale

try:
    LOCALE_PATH
except NameError:
    locale.setlocale(locale.LC_TIME, "")
    LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
    try:
        CURRENT_LANGUAGE = locale.getlocale()[0][:2]
    except:
        CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
    try:
        t = gettext.translation('novelibre', LOCALE_PATH, languages=[CURRENT_LANGUAGE])
        _ = t.gettext
    except:

        def _(message):
            return message

WEEKDAYS = calendar.day_name
MONTHS = calendar.month_name

from tkinter import messagebox



class UiFacade(Ui):

    def __init__(self, title):
        Ui.__init__(self, title)

    def ask_ok_cancel(self, text, title=None, **options):
        if title is None:
            title = self.title
        return messagebox.askokcancel(title, text, **options)

    def ask_yes_no(self, text, title=None, **options):
        if title is None:
            title = self.title
        return messagebox.askyesno(title, text, **options)

    def ask_yes_no_cancel(self, text, title=None, **options):
        if title is None:
            title = self.title
        return messagebox.askyesnocancel(title, text, **options)

    def show_error(self, message, title=None, **options):
        if title is None:
            title = self.title
        messagebox.showerror(title, message, **options)

    def show_info(self, message, title=None, **options):
        if title is None:
            title = self.title
        messagebox.showinfo(title, message, **options)

    def show_warning(self, message, title=None, **options):
        if title is None:
            title = self.title
        messagebox.showwarning(title, message, **options)

import tkinter as tk


class UiTk(UiFacade):

    def __init__(self, title):
        super().__init__(title)
        self.title = title
        self.root = tk.Tk()
        self.root.minsize(400, 150)
        self.root.resizable(width='false', height='false')
        self.root.title(title)
        self._appInfo = tk.Label(self.root, text='')
        self._appInfo.pack(padx=20, pady=5)
        self._processInfo = tk.Label(self.root, text='', padx=20)
        self._processInfo.pack(pady=20, fill='both')
        self.root.quitButton = tk.Button(text=_("Quit"), command=quit)
        self.root.quitButton.config(height=1, width=10)
        self.root.quitButton.pack(pady=10)

    def set_status(self, message):
        if message.startswith('!'):
            self._processInfo.config(bg='red')
            self._processInfo.config(fg='white')
            self.infoHowText = message.split('!', maxsplit=1)[1].strip()
        else:
            self._processInfo.config(bg='green')
            self._processInfo.config(fg='white')
            self.infoHowText = message
        self._processInfo.config(text=self.infoHowText)

    def set_info(self, message):
        self.infoWhatText = message
        self._appInfo.config(text=message)

    def show_open_button(self, open_cmd):
        self.root.openButton = tk.Button(text=_("Open"), command=open_cmd)
        self.root.openButton.config(height=1, width=10)
        self.root.openButton.pack(pady=10)

    def start(self):
        self.root.mainloop()


from datetime import date
import re

from datetime import date
from datetime import time


ROOT_PREFIX = 'rt'
CHAPTER_PREFIX = 'ch'
PLOT_LINE_PREFIX = 'ac'
SECTION_PREFIX = 'sc'
PLOT_POINT_PREFIX = 'ap'
CHARACTER_PREFIX = 'cr'
LOCATION_PREFIX = 'lc'
ITEM_PREFIX = 'it'
PRJ_NOTE_PREFIX = 'pn'
CH_ROOT = f'{ROOT_PREFIX}{CHAPTER_PREFIX}'
PL_ROOT = f'{ROOT_PREFIX}{PLOT_LINE_PREFIX}'
CR_ROOT = f'{ROOT_PREFIX}{CHARACTER_PREFIX}'
LC_ROOT = f'{ROOT_PREFIX}{LOCATION_PREFIX}'
IT_ROOT = f'{ROOT_PREFIX}{ITEM_PREFIX}'
PN_ROOT = f'{ROOT_PREFIX}{PRJ_NOTE_PREFIX}'

BRF_SYNOPSIS_SUFFIX = '_brf_synopsis'
CHAPTERS_SUFFIX = '_chapters_tmp'
CHARACTER_REPORT_SUFFIX = '_character_report'
CHARACTERS_SUFFIX = '_characters_tmp'
CHARLIST_SUFFIX = '_charlist_tmp'
DATA_SUFFIX = '_data'
ELEMENT_NOTES_SUFFIX = '_element_note_report',
GRID_SUFFIX = '_grid_tmp'
ITEM_REPORT_SUFFIX = '_item_report'
ITEMLIST_SUFFIX = '_itemlist_tmp'
ITEMS_SUFFIX = '_items_tmp'
LOCATION_REPORT_SUFFIX = '_location_report'
LOCATIONS_SUFFIX = '_locations_tmp'
LOCLIST_SUFFIX = '_loclist_tmp'
MAJOR_MARKER = _('Major Character')
MANUSCRIPT_SUFFIX = '_manuscript_tmp'
MINOR_MARKER = _('Minor Character')
PARTS_SUFFIX = '_parts_tmp'
PLOTLIST_SUFFIX = '_plotlist'
PLOTLINES_SUFFIX = '_plotlines_tmp'
PROJECTNOTES_SUFFIX = '_projectnote_report'
PROOF_SUFFIX = '_proof_tmp'
SECTIONLIST_SUFFIX = '_sectionlist'
SECTIONS_SUFFIX = '_sections_tmp'
STAGES_SUFFIX = '_structure_tmp'
TIMETABLE_SUFFIX = '_tt_tmp'
XREF_SUFFIX = '_xref'


class Error(Exception):
    pass


class Notification(Error):
    pass


def norm_path(path):
    if path is None:
        path = ''
    return os.path.normpath(path)


def string_to_list(text, divider=';'):
    elements = []
    try:
        tempList = text.split(divider)
        for element in tempList:
            element = element.strip()
            if element and not element in elements:
                elements.append(element)
        return elements

    except:
        return []


def list_to_string(elements, divider=';'):
    try:
        text = divider.join(elements)
        return text

    except:
        return ''


def intersection(elemList, refList):
    return [elem for elem in elemList if elem in refList]


def verified_date(dateStr):
    if dateStr is not None:
        date.fromisoformat(dateStr)
    return dateStr


def verified_int_string(intStr):
    if intStr is not None:
        int(intStr)
    return intStr


def verified_time(timeStr):
    if  timeStr is not None:
        time.fromisoformat(timeStr)
        while timeStr.count(':') < 2:
            timeStr = f'{timeStr}:00'
    return timeStr

import xml.etree.ElementTree as ET


class BasicElement:

    def __init__(self,
            on_element_change=None,
            title=None,
            desc=None,
            links=None):
        if on_element_change is None:
            self.on_element_change = self.do_nothing
        else:
            self.on_element_change = on_element_change
        self._title = title
        self._desc = desc
        if links is None:
            self._links = {}
        else:
            self._links = links
        self._fields = {}

    @property
    def title(self):
        return self._title

    @title.setter
    def title(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._title != newVal:
            self._title = newVal
            self.on_element_change()

    @property
    def desc(self):
        return self._desc

    @desc.setter
    def desc(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._desc != newVal:
            self._desc = newVal
            self.on_element_change()

    @property
    def links(self):
        try:
            return self._links.copy()
        except AttributeError:
            return None

    @links.setter
    def links(self, newVal):
        if newVal is not None:
            for elem in newVal:
                val = newVal[elem]
                if val is not None:
                    assert type(val) == str
        if self._links != newVal:
            self._links = newVal
            self.on_element_change()

    @property
    def fields(self):
        return self._fields.copy()

    @fields.setter
    def fields(self, newVal):
        if self._fields != newVal:
            self._fields = newVal
            self.on_element_change()

    def do_nothing(self):
        pass

    def from_xml(self, xmlElement):
        self.title = self._get_element_text(xmlElement, 'Title')
        self.desc = self._xml_element_to_text(xmlElement.find('Desc'))
        self.links = self._get_link_dict(xmlElement)
        self.fields = self._get_fields(xmlElement)

    def to_xml(self, xmlElement):
        if self.title:
            ET.SubElement(xmlElement, 'Title').text = self.title
        if self.desc:
            xmlElement.append(self._text_to_xml_element('Desc', self.desc))
        for path in self.links:
            xmlLink = ET.SubElement(xmlElement, 'Link')
            ET.SubElement(xmlLink, 'Path').text = path
            if self.links[path]:
                ET.SubElement(xmlLink, 'FullPath').text = self.links[path]
        for tag in self.fields:
            xmlField = ET.SubElement(xmlElement, 'Field')
            xmlField.set('tag', tag)
            xmlField.text = self.fields[tag]

    def _get_element_text(self, xmlElement, tag, default=None):
        if xmlElement.find(tag) is not None:
            return xmlElement.find(tag).text
        else:
            return default

    def _get_fields(self, xmlElement):
        fields = {}
        for xmlField in xmlElement.iterfind('Field'):
            tag = xmlField.get('tag', None)
            if tag is not None:
                fields[tag] = xmlField.text
        return fields

    def _get_link_dict(self, xmlElement):
        links = {}
        for xmlLink in xmlElement.iterfind('Link'):
            xmlPath = xmlLink.find('Path')
            if xmlPath is not None:
                path = xmlPath.text
                xmlFullPath = xmlLink.find('FullPath')
                if xmlFullPath is not None:
                    fullPath = xmlFullPath.text
                else:
                    fullPath = None
            else:
                path = xmlLink.attrib.get('path', None)
                fullPath = xmlLink.attrib.get('fullPath', None)
            if path:
                links[path] = fullPath
        return links

    def _text_to_xml_element(self, tag, text):
        xmlElement = ET.Element(tag)
        if text:
            for line in text.split('\n'):
                ET.SubElement(xmlElement, 'p').text = line
        return xmlElement

    def _xml_element_to_text(self, xmlElement):
        lines = []
        if xmlElement is not None:
            for paragraph in xmlElement.iterfind('p'):
                lines.append(''.join(t for t in paragraph.itertext()))
        return '\n'.join(lines)


LANGUAGE_TAG = re.compile(r'\<span xml\:lang=\"(.*?)\"\>')


class Novel(BasicElement):

    def __init__(self,
            authorName=None,
            wordTarget=None,
            wordCountStart=None,
            languageCode=None,
            countryCode=None,
            renumberChapters=None,
            renumberParts=None,
            renumberWithinParts=None,
            romanChapterNumbers=None,
            romanPartNumbers=None,
            saveWordCount=None,
            workPhase=None,
            chapterHeadingPrefix=None,
            chapterHeadingSuffix=None,
            partHeadingPrefix=None,
            partHeadingSuffix=None,
            customPlotProgress=None,
            customCharacterization=None,
            customWorldBuilding=None,
            customGoal=None,
            customConflict=None,
            customOutcome=None,
            customChrBio=None,
            customChrGoals=None,
            referenceDate=None,
            tree=None,
            **kwargs):
        super().__init__(**kwargs)
        self._authorName = authorName
        self._wordTarget = wordTarget
        self._wordCountStart = wordCountStart
        self._languageCode = languageCode
        self._countryCode = countryCode
        self._renumberChapters = renumberChapters
        self._renumberParts = renumberParts
        self._renumberWithinParts = renumberWithinParts
        self._romanChapterNumbers = romanChapterNumbers
        self._romanPartNumbers = romanPartNumbers
        self._saveWordCount = saveWordCount
        self._workPhase = workPhase
        self._chapterHeadingPrefix = chapterHeadingPrefix
        self._chapterHeadingSuffix = chapterHeadingSuffix
        self._partHeadingPrefix = partHeadingPrefix
        self._partHeadingSuffix = partHeadingSuffix
        self._customPlotProgress = customPlotProgress
        self._customCharacterization = customCharacterization
        self._customWorldBuilding = customWorldBuilding
        self._customGoal = customGoal
        self._customConflict = customConflict
        self._customOutcome = customOutcome
        self._customChrBio = customChrBio
        self._customChrGoals = customChrGoals

        self.chapters = {}
        self.sections = {}
        self.plotPoints = {}
        self.languages = None
        self.plotLines = {}
        self.locations = {}
        self.items = {}
        self.characters = {}
        self.projectNotes = {}
        try:
            self.referenceWeekDay = date.fromisoformat(referenceDate).weekday()
            self._referenceDate = referenceDate
        except:
            self.referenceWeekDay = None
            self._referenceDate = None
        self.tree = tree

    @property
    def authorName(self):
        return self._authorName

    @authorName.setter
    def authorName(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._authorName != newVal:
            self._authorName = newVal
            self.on_element_change()

    @property
    def wordTarget(self):
        return self._wordTarget

    @wordTarget.setter
    def wordTarget(self, newVal):
        if newVal is not None:
            assert type(newVal) == int
        if self._wordTarget != newVal:
            self._wordTarget = newVal
            self.on_element_change()

    @property
    def wordCountStart(self):
        return self._wordCountStart

    @wordCountStart.setter
    def wordCountStart(self, newVal):
        if newVal is not None:
            assert type(newVal) == int
        if self._wordCountStart != newVal:
            self._wordCountStart = newVal
            self.on_element_change()

    @property
    def languageCode(self):
        return self._languageCode

    @languageCode.setter
    def languageCode(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._languageCode != newVal:
            self._languageCode = newVal
            self.on_element_change()

    @property
    def countryCode(self):
        return self._countryCode

    @countryCode.setter
    def countryCode(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._countryCode != newVal:
            self._countryCode = newVal
            self.on_element_change()

    @property
    def renumberChapters(self):
        return self._renumberChapters

    @renumberChapters.setter
    def renumberChapters(self, newVal):
        if newVal is not None:
            assert type(newVal) == bool
        if self._renumberChapters != newVal:
            self._renumberChapters = newVal
            self.on_element_change()

    @property
    def renumberParts(self):
        return self._renumberParts

    @renumberParts.setter
    def renumberParts(self, newVal):
        if newVal is not None:
            assert type(newVal) == bool
        if self._renumberParts != newVal:
            self._renumberParts = newVal
            self.on_element_change()

    @property
    def renumberWithinParts(self):
        return self._renumberWithinParts

    @renumberWithinParts.setter
    def renumberWithinParts(self, newVal):
        if newVal is not None:
            assert type(newVal) == bool
        if self._renumberWithinParts != newVal:
            self._renumberWithinParts = newVal
            self.on_element_change()

    @property
    def romanChapterNumbers(self):
        return self._romanChapterNumbers

    @romanChapterNumbers.setter
    def romanChapterNumbers(self, newVal):
        if newVal is not None:
            assert type(newVal) == bool
        if self._romanChapterNumbers != newVal:
            self._romanChapterNumbers = newVal
            self.on_element_change()

    @property
    def romanPartNumbers(self):
        return self._romanPartNumbers

    @romanPartNumbers.setter
    def romanPartNumbers(self, newVal):
        if newVal is not None:
            assert type(newVal) == bool
        if self._romanPartNumbers != newVal:
            self._romanPartNumbers = newVal
            self.on_element_change()

    @property
    def saveWordCount(self):
        return self._saveWordCount

    @saveWordCount.setter
    def saveWordCount(self, newVal):
        if newVal is not None:
            assert type(newVal) == bool
        if self._saveWordCount != newVal:
            self._saveWordCount = newVal
            self.on_element_change()

    @property
    def workPhase(self):
        return self._workPhase

    @workPhase.setter
    def workPhase(self, newVal):
        if newVal is not None:
            assert type(newVal) == int
        if self._workPhase != newVal:
            self._workPhase = newVal
            self.on_element_change()

    @property
    def chapterHeadingPrefix(self):
        return self._chapterHeadingPrefix

    @chapterHeadingPrefix.setter
    def chapterHeadingPrefix(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._chapterHeadingPrefix != newVal:
            self._chapterHeadingPrefix = newVal
            self.on_element_change()

    @property
    def chapterHeadingSuffix(self):
        return self._chapterHeadingSuffix

    @chapterHeadingSuffix.setter
    def chapterHeadingSuffix(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._chapterHeadingSuffix != newVal:
            self._chapterHeadingSuffix = newVal
            self.on_element_change()

    @property
    def partHeadingPrefix(self):
        return self._partHeadingPrefix

    @partHeadingPrefix.setter
    def partHeadingPrefix(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._partHeadingPrefix != newVal:
            self._partHeadingPrefix = newVal
            self.on_element_change()

    @property
    def partHeadingSuffix(self):
        return self._partHeadingSuffix

    @partHeadingSuffix.setter
    def partHeadingSuffix(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._partHeadingSuffix != newVal:
            self._partHeadingSuffix = newVal
            self.on_element_change()

    @property
    def customPlotProgress(self):
        return self._customPlotProgress

    @customPlotProgress.setter
    def customPlotProgress(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._customPlotProgress != newVal:
            self._customPlotProgress = newVal
            self.on_element_change()

    @property
    def customCharacterization(self):
        return self._customCharacterization

    @customCharacterization.setter
    def customCharacterization(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._customCharacterization != newVal:
            self._customCharacterization = newVal
            self.on_element_change()

    @property
    def customWorldBuilding(self):
        return self._customWorldBuilding

    @customWorldBuilding.setter
    def customWorldBuilding(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._customWorldBuilding != newVal:
            self._customWorldBuilding = newVal
            self.on_element_change()

    @property
    def customGoal(self):
        return self._customGoal

    @customGoal.setter
    def customGoal(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._customGoal != newVal:
            self._customGoal = newVal
            self.on_element_change()

    @property
    def customConflict(self):
        return self._customConflict

    @customConflict.setter
    def customConflict(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._customConflict != newVal:
            self._customConflict = newVal
            self.on_element_change()

    @property
    def customOutcome(self):
        return self._customOutcome

    @customOutcome.setter
    def customOutcome(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._customOutcome != newVal:
            self._customOutcome = newVal
            self.on_element_change()

    @property
    def customChrBio(self):
        return self._customChrBio

    @customChrBio.setter
    def customChrBio(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._customChrBio != newVal:
            self._customChrBio = newVal
            self.on_element_change()

    @property
    def customChrGoals(self):
        return self._customChrGoals

    @customChrGoals.setter
    def customChrGoals(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._customChrGoals != newVal:
            self._customChrGoals = newVal
            self.on_element_change()

    @property
    def referenceDate(self):
        return self._referenceDate

    @referenceDate.setter
    def referenceDate(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._referenceDate != newVal:
            if not newVal:
                self._referenceDate = None
                self.referenceWeekDay = None
                self.on_element_change()
            else:
                try:
                    self.referenceWeekDay = date.fromisoformat(newVal).weekday()
                except:
                    pass
                else:
                    self._referenceDate = newVal
                    self.on_element_change()

    def check_locale(self):
        if not self._languageCode or self._languageCode == 'None':
            try:
                sysLng, sysCtr = locale.getlocale()[0].split('_')
            except:
                sysLng, sysCtr = locale.getdefaultlocale()[0].split('_')
            self._languageCode = sysLng
            self._countryCode = sysCtr
            self.on_element_change()
            return

        try:
            if len(self._languageCode) == 2:
                if len(self._countryCode) == 2:
                    return
        except:
            pass
        self._languageCode = 'zxx'
        self._countryCode = 'none'
        self.on_element_change()

    def from_xml(self, xmlElement):
        super().from_xml(xmlElement)
        self.renumberChapters = xmlElement.get('renumberChapters', None) == '1'
        self.renumberParts = xmlElement.get('renumberParts', None) == '1'
        self.renumberWithinParts = xmlElement.get('renumberWithinParts', None) == '1'
        self.romanChapterNumbers = xmlElement.get('romanChapterNumbers', None) == '1'
        self.romanPartNumbers = xmlElement.get('romanPartNumbers', None) == '1'
        self.saveWordCount = xmlElement.get('saveWordCount', None) == '1'
        workPhase = xmlElement.get('workPhase', None)
        if workPhase in ('1', '2', '3', '4', '5'):
            self.workPhase = int(workPhase)
        else:
            self.workPhase = None

        self.authorName = self._get_element_text(xmlElement, 'Author')

        self.chapterHeadingPrefix = self._get_element_text(xmlElement, 'ChapterHeadingPrefix')
        self.chapterHeadingSuffix = self._get_element_text(xmlElement, 'ChapterHeadingSuffix')

        self.partHeadingPrefix = self._get_element_text(xmlElement, 'PartHeadingPrefix')
        self.partHeadingSuffix = self._get_element_text(xmlElement, 'PartHeadingSuffix')

        self.customPlotProgress = self._get_element_text(xmlElement, 'CustomPlotProgress')
        self.customCharacterization = self._get_element_text(xmlElement, 'CustomCharacterization')
        self.customWorldBuilding = self._get_element_text(xmlElement, 'CustomWorldBuilding')

        self.customGoal = self._get_element_text(xmlElement, 'CustomGoal')
        self.customConflict = self._get_element_text(xmlElement, 'CustomConflict')
        self.customOutcome = self._get_element_text(xmlElement, 'CustomOutcome')

        self.customChrBio = self._get_element_text(xmlElement, 'CustomChrBio')
        self.customChrGoals = self._get_element_text(xmlElement, 'CustomChrGoals')

        if xmlElement.find('WordCountStart') is not None:
            self.wordCountStart = int(xmlElement.find('WordCountStart').text)
        if xmlElement.find('WordTarget') is not None:
            self.wordTarget = int(xmlElement.find('WordTarget').text)

        self.referenceDate = verified_date(self._get_element_text(xmlElement, 'ReferenceDate'))

    def get_languages(self):

        def languages(text):
            if not text:
                return

            m = LANGUAGE_TAG.search(text)
            while m:
                text = text[m.span()[1]:]
                yield m.group(1)
                m = LANGUAGE_TAG.search(text)

        self.languages = []
        for scId in self.sections:
            text = self.sections[scId].sectionContent
            if not text:
                continue

            for language in languages(text):
                if not language in self.languages:
                    self.languages.append(language)

    def to_xml(self, xmlElement):
        super().to_xml(xmlElement)
        if self.renumberChapters:
            xmlElement.set('renumberChapters', '1')
        if self.renumberParts:
            xmlElement.set('renumberParts', '1')
        if self.renumberWithinParts:
            xmlElement.set('renumberWithinParts', '1')
        if self.romanChapterNumbers:
            xmlElement.set('romanChapterNumbers', '1')
        if self.romanPartNumbers:
            xmlElement.set('romanPartNumbers', '1')
        if self.saveWordCount:
            xmlElement.set('saveWordCount', '1')
        if self.workPhase is not None:
            xmlElement.set('workPhase', str(self.workPhase))

        if self.authorName:
            ET.SubElement(xmlElement, 'Author').text = self.authorName

        if self.chapterHeadingPrefix:
            ET.SubElement(xmlElement, 'ChapterHeadingPrefix').text = self.chapterHeadingPrefix
        if self.chapterHeadingSuffix:
            ET.SubElement(xmlElement, 'ChapterHeadingSuffix').text = self.chapterHeadingSuffix

        if self.partHeadingPrefix:
            ET.SubElement(xmlElement, 'PartHeadingPrefix').text = self.partHeadingPrefix
        if self.partHeadingSuffix:
            ET.SubElement(xmlElement, 'PartHeadingSuffix').text = self.partHeadingSuffix

        if self.customPlotProgress:
            ET.SubElement(xmlElement, 'CustomPlotProgress').text = self.customPlotProgress
        if self.customCharacterization:
            ET.SubElement(xmlElement, 'CustomCharacterization').text = self.customCharacterization
        if self.customWorldBuilding:
            ET.SubElement(xmlElement, 'CustomWorldBuilding').text = self.customWorldBuilding

        if self.customGoal:
            ET.SubElement(xmlElement, 'CustomGoal').text = self.customGoal
        if self.customConflict:
            ET.SubElement(xmlElement, 'CustomConflict').text = self.customConflict
        if self.customOutcome:
            ET.SubElement(xmlElement, 'CustomOutcome').text = self.customOutcome

        if self.customChrBio:
            ET.SubElement(xmlElement, 'CustomChrBio').text = self.customChrBio
        if self.customChrGoals:
            ET.SubElement(xmlElement, 'CustomChrGoals').text = self.customChrGoals

        if self.wordCountStart:
            ET.SubElement(xmlElement, 'WordCountStart').text = str(self.wordCountStart)
        if self.wordTarget:
            ET.SubElement(xmlElement, 'WordTarget').text = str(self.wordTarget)

        if self.referenceDate:
            ET.SubElement(xmlElement, 'ReferenceDate').text = self.referenceDate

    def update_plot_lines(self):
        for scId in self.sections:
            self.sections[scId].scPlotPoints = {}
            self.sections[scId].scPlotLines = []
            for plId in self.plotLines:
                if scId in self.plotLines[plId].sections:
                    self.sections[scId].scPlotLines.append(plId)
                    for ppId in self.tree.get_children(plId):
                        if self.plotPoints[ppId].sectionAssoc == scId:
                            self.sections[scId].scPlotPoints[ppId] = plId
                            break



class NvTree:

    def __init__(self):
        self.roots = {
            CH_ROOT:[],
            CR_ROOT:[],
            LC_ROOT:[],
            IT_ROOT:[],
            PL_ROOT:[],
            PN_ROOT:[],
        }
        self.srtSections = {}
        self.srtPlotPoints = {}

    def append(self, parent, iid):
        if parent in self.roots:
            self.roots[parent].append(iid)
            if parent == CH_ROOT:
                self.srtSections[iid] = []
            elif parent == PL_ROOT:
                self.srtPlotPoints[iid] = []
            return

        if parent.startswith(CHAPTER_PREFIX):
            if parent in self.srtSections:
                self.srtSections[parent].append(iid)
            else:
                self.srtSections[parent] = [iid]
            return

        if parent.startswith(PLOT_LINE_PREFIX):
            if parent in self.srtPlotPoints:
                self.srtPlotPoints[parent].append(iid)
            else:
                self.srtPlotPoints[parent] = [iid]

    def delete(self, *items):
        raise NotImplementedError

    def delete_children(self, parent):
        if parent in self.roots:
            self.roots[parent] = []
            if parent == CH_ROOT:
                self.srtSections = {}
                return

            if parent == PL_ROOT:
                self.srtPlotPoints = {}
            return

        if parent.startswith(CHAPTER_PREFIX):
            self.srtSections[parent] = []
            return

        if parent.startswith(PLOT_LINE_PREFIX):
            self.srtPlotPoints[parent] = []

    def get_children(self, item):
        if item in self.roots:
            return self.roots[item]

        if item.startswith(CHAPTER_PREFIX):
            return self.srtSections.get(item, [])

        if item.startswith(PLOT_LINE_PREFIX):
            return self.srtPlotPoints.get(item, [])

    def index(self, item):
        raise NotImplementedError

    def insert(self, parent, index, iid):
        if parent in self.roots:
            self.roots[parent].insert(index, iid)
            if parent == CH_ROOT:
                self.srtSections[iid] = []
            elif parent == PL_ROOT:
                self.srtPlotPoints[iid] = []
            return

        if parent.startswith(CHAPTER_PREFIX):
            if parent in self.srtSections:
                self.srtSections[parent].insert(index, iid)
            else:
                self.srtSections[parent] = [iid]
            return

        if parent.startswith(PLOT_LINE_PREFIX):
            if parent in self.srtPlotPoints:
                self.srtPlotPoints[parent].insert(index, iid)
            else:
                self.srtPlotPoints[parent] = [iid]

    def move(self, item, parent, index):
        raise NotImplementedError

    def next(self, item):
        raise NotImplementedError

    def parent(self, item):
        if item.startswith(PLOT_POINT_PREFIX):
            for plId, ppIds in self.srtPlotPoints.items():
                if item in ppIds:
                    return plId

        elif item.startswith(SECTION_PREFIX):
            for chId, scIds in self.srtSections.items():
                if item in scIds:
                    return chId

        elif item in self.roots:
            return ''

        else:
            for root in self.roots:
                if item in root:
                    return root

        raise KeyError

    def prev(self, item):
        raise NotImplementedError

    def reset(self):
        for item in self.roots:
            self.roots[item] = []
        self.srtSections = {}
        self.srtPlotPoints = {}

    def set_children(self, item, newchildren):
        if item in self.roots:
            self.roots[item] = newchildren[:]
            if item == CH_ROOT:
                self.srtSections = {}
                return

            if item == PL_ROOT:
                self.srtPlotPoints = {}
            return

        if item.startswith(CHAPTER_PREFIX):
            self.srtSections[item] = newchildren[:]
            return

        if item.startswith(PLOT_LINE_PREFIX):
            self.srtPlotPoints[item] = newchildren[:]


from datetime import date



class BasicElementNotes(BasicElement):

    def __init__(self,
            notes=None,
            **kwargs):
        super().__init__(**kwargs)
        self._notes = notes

    @property
    def notes(self):
        return self._notes

    @notes.setter
    def notes(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._notes != newVal:
            self._notes = newVal
            self.on_element_change()

    def from_xml(self, xmlElement):
        super().from_xml(xmlElement)
        self.notes = self._xml_element_to_text(xmlElement.find('Notes'))

    def to_xml(self, xmlElement):
        super().to_xml(xmlElement)
        if self.notes:
            xmlElement.append(self._text_to_xml_element('Notes', self.notes))



class Chapter(BasicElementNotes):

    def __init__(self,
            chLevel=None,
            chType=None,
            noNumber=None,
            isTrash=None,
            **kwargs):
        super().__init__(**kwargs)
        self._chLevel = chLevel
        self._chType = chType
        self._noNumber = noNumber
        self._isTrash = isTrash

    @property
    def chLevel(self):
        return self._chLevel

    @chLevel.setter
    def chLevel(self, newVal):
        if newVal is not None:
            assert type(newVal) == int
        if self._chLevel != newVal:
            self._chLevel = newVal
            self.on_element_change()

    @property
    def chType(self):
        return self._chType

    @chType.setter
    def chType(self, newVal):
        if newVal is not None:
            assert type(newVal) == int
        if self._chType != newVal:
            self._chType = newVal
            self.on_element_change()

    @property
    def noNumber(self):
        return self._noNumber

    @noNumber.setter
    def noNumber(self, newVal):
        if newVal is not None:
            assert type(newVal) == bool
        if self._noNumber != newVal:
            self._noNumber = newVal
            self.on_element_change()

    @property
    def isTrash(self):
        return self._isTrash

    @isTrash.setter
    def isTrash(self, newVal):
        if newVal is not None:
            assert type(newVal) == bool
        if self._isTrash != newVal:
            self._isTrash = newVal
            self.on_element_change()

    def from_xml(self, xmlElement):
        super().from_xml(xmlElement)
        typeStr = xmlElement.get('type', '0')
        if typeStr in ('0', '1'):
            self.chType = int(typeStr)
        else:
            self.chType = 1
        chLevel = xmlElement.get('level', None)
        if chLevel == '1':
            self.chLevel = 1
        else:
            self.chLevel = 2
        self.isTrash = xmlElement.get('isTrash', None) == '1'
        self.noNumber = xmlElement.get('noNumber', None) == '1'

    def to_xml(self, xmlElement):
        super().to_xml(xmlElement)
        if self.chType:
            xmlElement.set('type', str(self.chType))
        if self.chLevel == 1:
            xmlElement.set('level', '1')
        if self.isTrash:
            xmlElement.set('isTrash', '1')
        if self.noNumber:
            xmlElement.set('noNumber', '1')


class BasicElementTags(BasicElementNotes):

    def __init__(self,
            tags=None,
            **kwargs):
        super().__init__(**kwargs)
        self._tags = tags

    @property
    def tags(self):
        return self._tags

    @tags.setter
    def tags(self, newVal):
        if newVal is not None:
            for elem in newVal:
                if elem is not None:
                    assert type(elem) == str
        if self._tags != newVal:
            self._tags = newVal
            self.on_element_change()

    def from_xml(self, xmlElement):
        super().from_xml(xmlElement)
        tags = string_to_list(self._get_element_text(xmlElement, 'Tags'))
        strippedTags = []
        for tag in tags:
            strippedTags.append(tag.strip())
        self.tags = strippedTags

    def to_xml(self, xmlElement):
        super().to_xml(xmlElement)
        tagStr = list_to_string(self.tags)
        if tagStr:
            ET.SubElement(xmlElement, 'Tags').text = tagStr



class WorldElement(BasicElementTags):

    def __init__(self,
            aka=None,
            **kwargs):
        super().__init__(**kwargs)
        self._aka = aka

    @property
    def aka(self):
        return self._aka

    @aka.setter
    def aka(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._aka != newVal:
            self._aka = newVal
            self.on_element_change()

    def from_xml(self, xmlElement):
        super().from_xml(xmlElement)
        self.aka = self._get_element_text(xmlElement, 'Aka')

    def to_xml(self, xmlElement):
        super().to_xml(xmlElement)
        if self.aka:
            ET.SubElement(xmlElement, 'Aka').text = self.aka



class Character(WorldElement):

    def __init__(self,
            bio=None,
            goals=None,
            fullName=None,
            isMajor=None,
            birthDate=None,
            deathDate=None,
            **kwargs):
        super().__init__(**kwargs)
        self._bio = bio
        self._goals = goals
        self._fullName = fullName
        self._isMajor = isMajor
        self._birthDate = birthDate
        self._deathDate = deathDate

    @property
    def bio(self):
        return self._bio

    @bio.setter
    def bio(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._bio != newVal:
            self._bio = newVal
            self.on_element_change()

    @property
    def goals(self):
        return self._goals

    @goals.setter
    def goals(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._goals != newVal:
            self._goals = newVal
            self.on_element_change()

    @property
    def fullName(self):
        return self._fullName

    @fullName.setter
    def fullName(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._fullName != newVal:
            self._fullName = newVal
            self.on_element_change()

    @property
    def isMajor(self):
        return self._isMajor

    @isMajor.setter
    def isMajor(self, newVal):
        if newVal is not None:
            assert type(newVal) == bool
        if self._isMajor != newVal:
            self._isMajor = newVal
            self.on_element_change()

    @property
    def birthDate(self):
        return self._birthDate

    @birthDate.setter
    def birthDate(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._birthDate != newVal:
            self._birthDate = newVal
            self.on_element_change()

    @property
    def deathDate(self):
        return self._deathDate

    @deathDate.setter
    def deathDate(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._deathDate != newVal:
            self._deathDate = newVal
            self.on_element_change()

    def from_xml(self, xmlElement):
        super().from_xml(xmlElement)
        self.isMajor = xmlElement.get('major', None) == '1'
        self.fullName = self._get_element_text(xmlElement, 'FullName')
        self.bio = self._xml_element_to_text(xmlElement.find('Bio'))
        self.goals = self._xml_element_to_text(xmlElement.find('Goals'))
        self.birthDate = verified_date(self._get_element_text(xmlElement, 'BirthDate'))
        self.deathDate = verified_date(self._get_element_text(xmlElement, 'DeathDate'))

    def to_xml(self, xmlElement):
        super().to_xml(xmlElement)
        if self.isMajor:
            xmlElement.set('major', '1')
        if self.fullName:
            ET.SubElement(xmlElement, 'FullName').text = self.fullName
        if self.bio:
            xmlElement.append(self._text_to_xml_element('Bio', self.bio))
        if self.goals:
            xmlElement.append(self._text_to_xml_element('Goals', self.goals))
        if self.birthDate:
            ET.SubElement(xmlElement, 'BirthDate').text = self.birthDate
        if self.deathDate:
            ET.SubElement(xmlElement, 'DeathDate').text = self.deathDate



class PlotLine(BasicElementNotes):

    def __init__(self,
            shortName=None,
            sections=None,
            **kwargs):
        super().__init__(**kwargs)

        self._shortName = shortName
        self._sections = sections

    @property
    def shortName(self):
        return self._shortName

    @shortName.setter
    def shortName(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._shortName != newVal:
            self._shortName = newVal
            self.on_element_change()

    @property
    def sections(self):
        try:
            return self._sections[:]
        except TypeError:
            return None

    @sections.setter
    def sections(self, newVal):
        if newVal is not None:
            for elem in newVal:
                if elem is not None:
                    assert type(elem) == str
        if self._sections != newVal:
            self._sections = newVal
            self.on_element_change()

    def from_xml(self, xmlElement):
        super().from_xml(xmlElement)
        self.shortName = self._get_element_text(xmlElement, 'ShortName')
        plSections = []
        xmlSections = xmlElement.find('Sections')
        if xmlSections is not None:
            scIds = xmlSections.get('ids', None)
            if scIds is not None:
                for scId in string_to_list(scIds, divider=' '):
                    plSections.append(scId)
        self.sections = plSections

    def to_xml(self, xmlElement):
        super().to_xml(xmlElement)
        if self.shortName:
            ET.SubElement(xmlElement, 'ShortName').text = self.shortName
        if self.sections:
            attrib = {'ids':' '.join(self.sections)}
            ET.SubElement(xmlElement, 'Sections', attrib=attrib)


class PlotPoint(BasicElementNotes):

    def __init__(self,
            sectionAssoc=None,
            **kwargs):
        super().__init__(**kwargs)

        self._sectionAssoc = sectionAssoc

    @property
    def sectionAssoc(self):
        return self._sectionAssoc

    @sectionAssoc.setter
    def sectionAssoc(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._sectionAssoc != newVal:
            self._sectionAssoc = newVal
            self.on_element_change()

    def from_xml(self, xmlElement):
        super().from_xml(xmlElement)
        xmlSectionAssoc = xmlElement.find('Section')
        if xmlSectionAssoc is not None:
            self.sectionAssoc = xmlSectionAssoc.get('id', None)

    def to_xml(self, xmlElement):
        super().to_xml(xmlElement)
        if self.sectionAssoc:
            ET.SubElement(xmlElement, 'Section', attrib={'id': self.sectionAssoc})
from datetime import date
from datetime import datetime
from datetime import time
from datetime import timedelta

from calendar import isleap
from datetime import date
from datetime import datetime
from datetime import timedelta


def difference_in_years(startDate, endDate):
    diffyears = endDate.year - startDate.year
    difference = endDate - startDate.replace(endDate.year)
    days_in_year = isleap(endDate.year) and 366 or 365
    years = diffyears + (difference.days + difference.seconds / 86400.0) / days_in_year
    return int(years)


def get_age(nowIso, birthDateIso, deathDateIso):
    now = datetime.fromisoformat(nowIso)
    if deathDateIso:
        deathDate = datetime.fromisoformat(deathDateIso)
        if now > deathDate:
            years = difference_in_years(deathDate, now)
            return -1 * years

    birthDate = datetime.fromisoformat(birthDateIso)
    years = difference_in_years(birthDate, now)
    return years


def get_specific_date(dayStr, refIso):
    refDate = date.fromisoformat(refIso)
    return date.isoformat(refDate + timedelta(days=int(dayStr)))


def get_unspecific_date(dateIso, refIso):
    refDate = date.fromisoformat(refIso)
    return str((date.fromisoformat(dateIso) - refDate).days)


ADDITIONAL_WORD_LIMITS = re.compile(r'--|—|–|\<\/p\>')

NO_WORD_LIMITS = re.compile(r'\<note\>.*?\<\/note\>|\<comment\>.*?\<\/comment\>|\<.+?\>')


class Section(BasicElementTags):

    SCENE = ['-', 'A', 'R', 'x']

    STATUS = [
        None,
        _('Outline'),
        _('Draft'),
        _('1st Edit'),
        _('2nd Edit'),
        _('Done')
    ]

    NULL_DATE = '0001-01-01'
    NULL_TIME = '00:00:00'

    def __init__(self,
            scType=None,
            scene=None,
            status=None,
            appendToPrev=None,
            goal=None,
            conflict=None,
            outcome=None,
            plotNotes=None,
            scDate=None,
            scTime=None,
            day=None,
            lastsMinutes=None,
            lastsHours=None,
            lastsDays=None,
            characters=None,
            locations=None,
            items=None,
            **kwargs):
        super().__init__(**kwargs)
        self._sectionContent = None
        self.wordCount = 0

        self._scType = scType
        self._scene = scene
        self._status = status
        self._appendToPrev = appendToPrev
        self._goal = goal
        self._conflict = conflict
        self._outcome = outcome
        self._plotlineNotes = plotNotes
        try:
            newDate = date.fromisoformat(scDate)
            self._weekDay = newDate.weekday()
            self._localeDate = newDate.strftime('%x')
            self._date = scDate
        except:
            self._weekDay = None
            self._localeDate = None
            self._date = None
        self._time = scTime
        self._day = day
        self._lastsMinutes = lastsMinutes
        self._lastsHours = lastsHours
        self._lastsDays = lastsDays
        self._characters = characters
        self._locations = locations
        self._items = items

        self.scPlotLines = []
        self.scPlotPoints = {}

    @property
    def sectionContent(self):
        return self._sectionContent

    @sectionContent.setter
    def sectionContent(self, text):
        if text is not None:
            assert type(text) == str
        if self._sectionContent != text:
            self._sectionContent = text
            if text is not None:
                text = ADDITIONAL_WORD_LIMITS.sub(' ', text)
                text = NO_WORD_LIMITS.sub('', text)
                wordList = text.split()
                self.wordCount = len(wordList)
            else:
                self.wordCount = 0
            self.on_element_change()

    @property
    def scType(self):
        return self._scType

    @scType.setter
    def scType(self, newVal):
        if newVal is not None:
            assert type(newVal) == int
        if self._scType != newVal:
            self._scType = newVal
            self.on_element_change()

    @property
    def scene(self):
        return self._scene

    @scene.setter
    def scene(self, newVal):
        if newVal is not None:
            assert type(newVal) == int
        if self._scene != newVal:
            self._scene = newVal
            self.on_element_change()

    @property
    def status(self):
        return self._status

    @status.setter
    def status(self, newVal):
        if newVal is not None:
            assert type(newVal) == int
        if self._status != newVal:
            self._status = newVal
            self.on_element_change()

    @property
    def appendToPrev(self):
        return self._appendToPrev

    @appendToPrev.setter
    def appendToPrev(self, newVal):
        if newVal is not None:
            assert type(newVal) == bool
        if self._appendToPrev != newVal:
            self._appendToPrev = newVal
            self.on_element_change()

    @property
    def goal(self):
        return self._goal

    @goal.setter
    def goal(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._goal != newVal:
            self._goal = newVal
            self.on_element_change()

    @property
    def conflict(self):
        return self._conflict

    @conflict.setter
    def conflict(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._conflict != newVal:
            self._conflict = newVal
            self.on_element_change()

    @property
    def outcome(self):
        return self._outcome

    @outcome.setter
    def outcome(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._outcome != newVal:
            self._outcome = newVal
            self.on_element_change()

    @property
    def plotlineNotes(self):
        try:
            return dict(self._plotlineNotes)
        except TypeError:
            return None

    @plotlineNotes.setter
    def plotlineNotes(self, newVal):
        if newVal is not None:
            for elem in newVal:
                val = newVal[elem]
                if val is not None:
                    assert type(val) == str
        if self._plotlineNotes != newVal:
            self._plotlineNotes = newVal
            self.on_element_change()

    @property
    def date(self):
        return self._date

    @date.setter
    def date(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._date != newVal:
            if not newVal:
                self._date = None
                self._weekDay = None
                self._localeDate = None
                self.on_element_change()
                return

            try:
                newDate = date.fromisoformat(newVal)
                self._weekDay = newDate.weekday()
            except:
                return

            try:
                self._localeDate = newDate.strftime('%x')
            except:
                self._localeDate = newVal
            self._date = newVal
            self.on_element_change()

    @property
    def weekDay(self):
        return self._weekDay

    @property
    def localeDate(self):
        return self._localeDate

    @property
    def time(self):
        return self._time

    @time.setter
    def time(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._time != newVal:
            self._time = newVal
            self.on_element_change()

    @property
    def day(self):
        return self._day

    @day.setter
    def day(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._day != newVal:
            self._day = newVal
            self.on_element_change()

    @property
    def lastsMinutes(self):
        return self._lastsMinutes

    @lastsMinutes.setter
    def lastsMinutes(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._lastsMinutes != newVal:
            self._lastsMinutes = newVal
            self.on_element_change()

    @property
    def lastsHours(self):
        return self._lastsHours

    @lastsHours.setter
    def lastsHours(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._lastsHours != newVal:
            self._lastsHours = newVal
            self.on_element_change()

    @property
    def lastsDays(self):
        return self._lastsDays

    @lastsDays.setter
    def lastsDays(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._lastsDays != newVal:
            self._lastsDays = newVal
            self.on_element_change()

    @property
    def characters(self):
        try:
            return self._characters[:]
        except TypeError:
            return None

    @characters.setter
    def characters(self, newVal):
        if newVal is not None:
            for elem in newVal:
                if elem is not None:
                    assert type(elem) == str
        if self._characters != newVal:
            self._characters = newVal
            self.on_element_change()

    @property
    def locations(self):
        try:
            return self._locations[:]
        except TypeError:
            return None

    @locations.setter
    def locations(self, newVal):
        if newVal is not None:
            for elem in newVal:
                if elem is not None:
                    assert type(elem) == str
        if self._locations != newVal:
            self._locations = newVal
            self.on_element_change()

    @property
    def items(self):
        try:
            return self._items[:]
        except TypeError:
            return None

    @items.setter
    def items(self, newVal):
        if newVal is not None:
            for elem in newVal:
                if elem is not None:
                    assert type(elem) == str
        if self._items != newVal:
            self._items = newVal
            self.on_element_change()

    def day_to_date(self, referenceDate):
        if self._date:
            return True

        try:
            self.date = get_specific_date(self._day, referenceDate)
            self._day = None
            return True

        except:
            self.date = None
            return False

    def date_to_day(self, referenceDate):
        if self._day:
            return True

        try:
            self._day = get_unspecific_date(self._date, referenceDate)
            self.date = None
            return True

        except:
            self._day = None
            return False

    def from_xml(self, xmlElement):
        super().from_xml(xmlElement)

        typeStr = xmlElement.get('type', '0')
        if typeStr in ('0', '1', '2', '3'):
            self.scType = int(typeStr)
        else:
            self.scType = 1
        status = xmlElement.get('status', None)
        if status in ('2', '3', '4', '5'):
            self.status = int(status)
        else:
            self.status = 1
        scene = xmlElement.get('scene', 0)
        if scene in ('1', '2', '3'):
            self.scene = int(scene)
        else:
            self.scene = 0

        if not self.scene:
            sceneKind = xmlElement.get('pacing', None)
            if sceneKind in ('1', '2'):
                self.scene = int(sceneKind) + 1

        self.appendToPrev = xmlElement.get('append', None) == '1'

        self.goal = self._xml_element_to_text(xmlElement.find('Goal'))
        self.conflict = self._xml_element_to_text(xmlElement.find('Conflict'))
        self.outcome = self._xml_element_to_text(xmlElement.find('Outcome'))

        xmlPlotNotes = xmlElement.find('PlotNotes')
        if xmlPlotNotes is None:
            xmlPlotNotes = xmlElement
        plotNotes = {}
        for xmlPlotLineNote in xmlPlotNotes.iterfind('PlotlineNotes'):
            plId = xmlPlotLineNote.get('id', None)
            plotNotes[plId] = self._xml_element_to_text(xmlPlotLineNote)
        self.plotlineNotes = plotNotes

        if xmlElement.find('Date') is not None:
            self.date = verified_date(xmlElement.find('Date').text)
        elif xmlElement.find('Day') is not None:
            self.day = verified_int_string(xmlElement.find('Day').text)

        if xmlElement.find('Time') is not None:
            self.time = verified_time(xmlElement.find('Time').text)

        self.lastsDays = verified_int_string(self._get_element_text(xmlElement, 'LastsDays'))
        self.lastsHours = verified_int_string(self._get_element_text(xmlElement, 'LastsHours'))
        self.lastsMinutes = verified_int_string(self._get_element_text(xmlElement, 'LastsMinutes'))

        scCharacters = []
        xmlCharacters = xmlElement.find('Characters')
        if xmlCharacters is not None:
            crIds = xmlCharacters.get('ids', None)
            if crIds is not None:
                for crId in string_to_list(crIds, divider=' '):
                    scCharacters.append(crId)
        self.characters = scCharacters

        scLocations = []
        xmlLocations = xmlElement.find('Locations')
        if xmlLocations is not None:
            lcIds = xmlLocations.get('ids', None)
            if lcIds is not None:
                for lcId in string_to_list(lcIds, divider=' '):
                    scLocations.append(lcId)
        self.locations = scLocations

        scItems = []
        xmlItems = xmlElement.find('Items')
        if xmlItems is not None:
            itIds = xmlItems.get('ids', None)
            if itIds is not None:
                for itId in string_to_list(itIds, divider=' '):
                    scItems.append(itId)
        self.items = scItems

        xmlContent = xmlElement.find('Content')
        if xmlContent is not None:
            xmlStr = ET.tostring(
                xmlContent,
                encoding='utf-8',
                short_empty_elements=False
                ).decode('utf-8')
            xmlStr = xmlStr.replace('<Content>', '').replace('</Content>', '')

            lines = xmlStr.split('\n')
            newlines = []
            for line in lines:
                newlines.append(line.strip())
            xmlStr = ''.join(newlines)
            if xmlStr:
                self.sectionContent = xmlStr
            else:
                self.sectionContent = '<p></p>'
        elif self.scType < 2:
            self.sectionContent = '<p></p>'

    def get_end_date_time(self):

        def get_duration():
            if self.lastsDays:
                lastsDays = int(self.lastsDays)
            else:
                lastsDays = 0
            if self.lastsHours:
                lastsSeconds = int(self.lastsHours) * 3600
            else:
                lastsSeconds = 0
            if self.lastsMinutes:
                lastsSeconds += int(self.lastsMinutes) * 60
            return timedelta(days=lastsDays, seconds=lastsSeconds)

        def get_end_date_time(sectionDuration):
            sectionStart = datetime.fromisoformat(f'{self.date} {self.time}')
            sectionEnd = sectionStart + sectionDuration
            return sectionEnd.isoformat().split('T')

        def get_end_day_time(sectionDuration):
            if self.day:
                dayInt = int(self.day)
            else:
                dayInt = 0
            virtualStartDate = (date.min + timedelta(days=dayInt)).isoformat()
            virtualSectionStart = datetime.fromisoformat(f'{virtualStartDate} {self.time}')
            virtualSectionEnd = virtualSectionStart + sectionDuration
            virtualEndDate, endTime = virtualSectionEnd.isoformat().split('T')
            endDay = str((date.fromisoformat(virtualEndDate) - date.min).days)
            return (endDay, endTime)

        endDate = None
        endTime = None
        endDay = None
        if self.time:
            if self.date:
                try:
                    endDate, endTime = get_end_date_time(get_duration())
                except:
                    pass
            else:
                try:
                    endDay, endTime = get_end_day_time(get_duration())
                except:
                    pass
        return endDate, endTime, endDay

    def to_xml(self, xmlElement):
        super().to_xml(xmlElement)
        if self.scType:
            xmlElement.set('type', str(self.scType))
        if self.status > 1:
            xmlElement.set('status', str(self.status))
        if self.scene > 0:
            xmlElement.set('scene', str(self.scene))
        if self.appendToPrev:
            xmlElement.set('append', '1')

        if self.goal:
            xmlElement.append(self._text_to_xml_element('Goal', self.goal))
        if self.conflict:
            xmlElement.append(self._text_to_xml_element('Conflict', self.conflict))
        if self.outcome:
            xmlElement.append(self._text_to_xml_element('Outcome', self.outcome))

        if self.plotlineNotes:
            for plId in self.plotlineNotes:
                if not plId in self.scPlotLines:
                    continue

                if not self.plotlineNotes[plId]:
                    continue

                xmlPlotlineNotes = self._text_to_xml_element('PlotlineNotes', self.plotlineNotes[plId])
                xmlPlotlineNotes.set('id', plId)
                xmlElement.append(xmlPlotlineNotes)

        if self.date:
            ET.SubElement(xmlElement, 'Date').text = self.date
        elif self.day:
            ET.SubElement(xmlElement, 'Day').text = self.day
        if self.time:
            ET.SubElement(xmlElement, 'Time').text = self.time

        if self.lastsDays and self.lastsDays != '0':
            ET.SubElement(xmlElement, 'LastsDays').text = self.lastsDays
        if self.lastsHours and self.lastsHours != '0':
            ET.SubElement(xmlElement, 'LastsHours').text = self.lastsHours
        if self.lastsMinutes and self.lastsMinutes != '0':
            ET.SubElement(xmlElement, 'LastsMinutes').text = self.lastsMinutes

        if self.characters:
            attrib = {'ids':' '.join(self.characters)}
            ET.SubElement(xmlElement, 'Characters', attrib=attrib)

        if self.locations:
            attrib = {'ids':' '.join(self.locations)}
            ET.SubElement(xmlElement, 'Locations', attrib=attrib)

        if self.items:
            attrib = {'ids':' '.join(self.items)}
            ET.SubElement(xmlElement, 'Items', attrib=attrib)

        sectionContent = self.sectionContent
        if sectionContent:
            if not sectionContent in ('<p></p>', '<p />'):
                xmlElement.append(ET.fromstring(f'<Content>{sectionContent}</Content>'))
from abc import ABC
from urllib.parse import quote



class File(ABC):
    DESCRIPTION = _('File')
    EXTENSION = None
    SUFFIX = None

    def __init__(self, filePath, **kwargs):
        self.novel = None
        self._filePath = None
        self.projectName = None
        self.projectPath = None
        self.sectionsSplit = False
        self.filePath = filePath

    @property
    def filePath(self):
        return self._filePath

    @filePath.setter
    def filePath(self, filePath: str):
        filePath = filePath.replace('\\', '/')
        if self.SUFFIX is not None:
            suffix = self.SUFFIX
        else:
            suffix = ''
        if filePath.lower().endswith(f'{suffix}{self.EXTENSION}'.lower()):
            self._filePath = filePath
            try:
                head, tail = os.path.split(os.path.realpath(filePath))
            except:
                head, tail = os.path.split(filePath)
            self.projectPath = quote(head.replace('\\', '/'), '/:')
            self.projectName = quote(tail.replace(f'{suffix}{self.EXTENSION}', ''))

    def is_locked(self):
        return False

    def read(self):
        raise NotImplementedError

    def write(self):
        raise NotImplementedError



def strip_illegal_characters(text):
    return re.sub('[\x00-\x08|\x0b-\x0c|\x0e-\x1f]', '', text)



def indent(elem, level=0):
    PARAGRAPH_LEVEL = 5

    i = f'\n{level * "  "}'
    if len(elem):
        if not elem.text or not elem.text.strip():
            elem.text = f'{i}  '
        if not elem.tail or not elem.tail.strip():
            elem.tail = i
        if level < PARAGRAPH_LEVEL:
            for elem in elem:
                indent(elem, level + 1)
        if not elem.tail or not elem.tail.strip():
            elem.tail = i
    else:
        if level and (not elem.tail or not elem.tail.strip()):
            elem.tail = i


def get_xml_root(filePath):
    try:
        xmlTree = ET.parse(filePath)
    except Exception as ex:
        raise Error(f'{_("Cannot process file")}: "{norm_path(filePath)}" - {str(ex)}')

    return xmlTree.getroot()


class NovxFile(File):
    DESCRIPTION = _('novelibre project')
    EXTENSION = '.novx'

    MAJOR_VERSION = 1
    MINOR_VERSION = 5

    XML_HEADER = f'''<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE novx SYSTEM "novx_{MAJOR_VERSION}_{MINOR_VERSION}.dtd">
<?xml-stylesheet href="novx.css" type="text/css"?>
'''

    def __init__(self, filePath, **kwargs):
        super().__init__(filePath)
        self.on_element_change = None
        self.xmlTree = None

        self.wcLog = {}

        self.wcLogUpdate = {}

        self.timestamp = None

    def adjust_section_types(self):
        partType = 0
        for chId in self.novel.tree.get_children(CH_ROOT):
            if self.novel.chapters[chId].chLevel == 1:
                partType = self.novel.chapters[chId].chType
            elif partType != 0 and not self.novel.chapters[chId].isTrash:
                self.novel.chapters[chId].chType = partType
            for scId in self.novel.tree.get_children(chId):
                if self.novel.sections[scId].scType < self.novel.chapters[chId].chType:
                    self.novel.sections[scId].scType = self.novel.chapters[chId].chType

    def count_words(self):
        count = 0
        totalCount = 0
        for chId in self.novel.tree.get_children(CH_ROOT):
            if not self.novel.chapters[chId].isTrash:
                for scId in self.novel.tree.get_children(chId):
                    if self.novel.sections[scId].scType < 2:
                        totalCount += self.novel.sections[scId].wordCount
                        if self.novel.sections[scId].scType == 0:
                            count += self.novel.sections[scId].wordCount
        return count, totalCount

    def read(self):
        xmlRoot = get_xml_root(self.filePath)
        self._check_version(xmlRoot)
        try:
            locale = xmlRoot.attrib['{http://www.w3.org/XML/1998/namespace}lang']
            self.novel.languageCode, self.novel.countryCode = locale.split('-')
        except:
            pass
        self.novel.tree.reset()
        try:
            self._read_project(xmlRoot)
            self._read_locations(xmlRoot)
            self._read_items(xmlRoot)
            self._read_characters(xmlRoot)
            self._read_chapters_and_sections(xmlRoot)
            self._read_plot_lines_and_points(xmlRoot)
            self._read_project_notes(xmlRoot)
            self.adjust_section_types()
            self._read_word_count_log(xmlRoot)
        except Exception as ex:
            raise Error(f"{_('Corrupt project data')} ({str(ex)})")
        self._get_timestamp()
        self._keep_word_count()

    def write(self):
        self._update_word_count_log()
        self.adjust_section_types()
        self.novel.get_languages()

        attrib = {
            'version':f'{self.MAJOR_VERSION}.{self.MINOR_VERSION}',
            'xml:lang':f'{self.novel.languageCode}-{self.novel.countryCode}',
        }
        xmlRoot = ET.Element('novx', attrib=attrib)
        self._build_project(xmlRoot)
        self._build_chapters_and_sections(xmlRoot)
        self._build_characters(xmlRoot)
        self._build_locations(xmlRoot)
        self._build_items(xmlRoot)
        self._build_plot_lines_and_points(xmlRoot)
        self._build_project_notes(xmlRoot)
        self._build_word_count_log(xmlRoot)

        indent(xmlRoot)

        self.xmlTree = ET.ElementTree(xmlRoot)
        self._write_element_tree(self)
        self._postprocess_xml_file(self.filePath)
        self._get_timestamp()

    def _build_project(self, root):
        xmlProject = ET.SubElement(root, 'PROJECT')
        self.novel.to_xml(xmlProject)

    def _build_chapters_and_sections(self, root):
        xmlChapters = ET.SubElement(root, 'CHAPTERS')
        for chId in self.novel.tree.get_children(CH_ROOT):
            xmlChapter = ET.SubElement(xmlChapters, 'CHAPTER', attrib={'id':chId})
            self.novel.chapters[chId].to_xml(xmlChapter)
            for scId in self.novel.tree.get_children(chId):
                self.novel.sections[scId].to_xml(ET.SubElement(xmlChapter, 'SECTION', attrib={'id':scId}))

    def _build_characters(self, root):
        xmlCharacters = ET.SubElement(root, 'CHARACTERS')
        for crId in self.novel.tree.get_children(CR_ROOT):
            self.novel.characters[crId].to_xml(ET.SubElement(xmlCharacters, 'CHARACTER', attrib={'id':crId}))

    def _build_locations(self, root):
        xmlLocations = ET.SubElement(root, 'LOCATIONS')
        for lcId in self.novel.tree.get_children(LC_ROOT):
            self.novel.locations[lcId].to_xml(ET.SubElement(xmlLocations, 'LOCATION', attrib={'id':lcId}))

    def _build_items(self, root):
        xmlItems = ET.SubElement(root, 'ITEMS')
        for itId in self.novel.tree.get_children(IT_ROOT):
            self.novel.items[itId].to_xml(ET.SubElement(xmlItems, 'ITEM', attrib={'id':itId}))

    def _build_plot_lines_and_points(self, root):
        xmlPlotLines = ET.SubElement(root, 'ARCS')
        for plId in self.novel.tree.get_children(PL_ROOT):
            xmlPlotLine = ET.SubElement(xmlPlotLines, 'ARC', attrib={'id':plId})
            self.novel.plotLines[plId].to_xml(xmlPlotLine)
            for ppId in self.novel.tree.get_children(plId):
                self.novel.plotPoints[ppId].to_xml(ET.SubElement(xmlPlotLine, 'POINT', attrib={'id':ppId}))

    def _build_project_notes(self, root):
        xmlProjectNotes = ET.SubElement(root, 'PROJECTNOTES')
        for pnId in self.novel.tree.get_children(PN_ROOT):
            self.novel.projectNotes[pnId].to_xml(ET.SubElement(xmlProjectNotes, 'PROJECTNOTE', attrib={'id':pnId}))

    def _build_word_count_log(self, root):
        if not self.wcLog:
            return

        xmlWcLog = ET.SubElement(root, 'PROGRESS')
        wcLastCount = None
        wcLastTotalCount = None
        for wc in self.wcLog:
            if self.novel.saveWordCount:
                if self.wcLog[wc][0] == wcLastCount and self.wcLog[wc][1] == wcLastTotalCount:
                    continue

                wcLastCount = self.wcLog[wc][0]
                wcLastTotalCount = self.wcLog[wc][1]
            xmlWc = ET.SubElement(xmlWcLog, 'WC')
            ET.SubElement(xmlWc, 'Date').text = wc
            ET.SubElement(xmlWc, 'Count').text = self.wcLog[wc][0]
            ET.SubElement(xmlWc, 'WithUnused').text = self.wcLog[wc][1]

    def _check_id(self, elemId, elemPrefix):
        if not elemId.startswith(elemPrefix):
            raise Error(f"bad ID: '{elemId}'")

    def _check_version(self, xmlRoot):
        if xmlRoot.tag != 'novx':
            raise Error(f'{_("No valid xml root element found in file")}: "{norm_path(self.filePath)}".')
        try:
            majorVersionStr, minorVersionStr = xmlRoot.attrib['version'].split('.')
            majorVersion = int(majorVersionStr)
            minorVersion = int(minorVersionStr)
        except:
            raise Error(f'{_("No valid version found in file")}: "{norm_path(self.filePath)}".')
        if majorVersion > self.MAJOR_VERSION:
            raise Error(_('The project "{}" was created with a newer novelibre version.').format(norm_path(self.filePath)))
        elif majorVersion < self.MAJOR_VERSION:
            raise Error(_('The project "{}" was created with an outdated novelibre version.').format(norm_path(self.filePath)))
        elif minorVersion > self.MINOR_VERSION:
            raise Error(_('The project "{}" was created with a newer novelibre version.').format(norm_path(self.filePath)))

    def _get_timestamp(self):
        try:
            self.timestamp = os.path.getmtime(self.filePath)
        except:
            self.timestamp = None

    def _keep_word_count(self):
        if not self.wcLog:
            return

        actualCountInt, actualTotalCountInt = self.count_words()
        actualCount = str(actualCountInt)
        actualTotalCount = str(actualTotalCountInt)
        latestDate = list(self.wcLog)[-1]
        latestCount = self.wcLog[latestDate][0]
        latestTotalCount = self.wcLog[latestDate][1]
        if actualCount != latestCount or actualTotalCount != latestTotalCount:
            try:
                fileDateIso = date.fromtimestamp(self.timestamp).isoformat()
            except:
                fileDateIso = date.today().isoformat()
            self.wcLogUpdate[fileDateIso] = [actualCount, actualTotalCount]

    def _postprocess_xml_file(self, filePath):
        with open(filePath, 'r', encoding='utf-8') as f:
            text = f.read()
            text = strip_illegal_characters(text)
        try:
            with open(filePath, 'w', encoding='utf-8') as f:
                f.write(f'{self.XML_HEADER}{text}')
        except:
            raise Error(f'{_("Cannot write file")}: "{norm_path(filePath)}".')

    def _read_chapters_and_sections(self, root):
        xmlChapters = root.find('CHAPTERS')
        if xmlChapters is None:
            return

        for xmlChapter in xmlChapters.iterfind('CHAPTER'):
            chId = xmlChapter.attrib['id']
            self._check_id(chId, CHAPTER_PREFIX)
            self.novel.chapters[chId] = Chapter(on_element_change=self.on_element_change)
            self.novel.chapters[chId].from_xml(xmlChapter)
            self.novel.tree.append(CH_ROOT, chId)

            for xmlSection in xmlChapter.iterfind('SECTION'):
                scId = xmlSection.attrib['id']
                self._check_id(scId, SECTION_PREFIX)
                self._read_section(xmlSection, scId)
                self.novel.tree.append(chId, scId)

    def _read_characters(self, root):
        xmlCharacters = root.find('CHARACTERS')
        if xmlCharacters is None:
            return

        for xmlCharacter in xmlCharacters.iterfind('CHARACTER'):
            crId = xmlCharacter.attrib['id']
            self._check_id(crId, CHARACTER_PREFIX)
            self.novel.characters[crId] = Character(on_element_change=self.on_element_change)
            self.novel.characters[crId].from_xml(xmlCharacter)
            self.novel.tree.append(CR_ROOT, crId)

    def _read_items(self, root):
        xmlItems = root.find('ITEMS')
        if xmlItems is None:
            return

        for xmlItem in xmlItems.iterfind('ITEM'):
            itId = xmlItem.attrib['id']
            self._check_id(itId, ITEM_PREFIX)
            self.novel.items[itId] = WorldElement(on_element_change=self.on_element_change)
            self.novel.items[itId].from_xml(xmlItem)
            self.novel.tree.append(IT_ROOT, itId)

    def _read_locations(self, root):
        xmlLocations = root.find('LOCATIONS')
        if xmlLocations is None:
            return

        for xmlLocation in xmlLocations.iterfind('LOCATION'):
            lcId = xmlLocation.attrib['id']
            self._check_id(lcId, LOCATION_PREFIX)
            self.novel.locations[lcId] = WorldElement(on_element_change=self.on_element_change)
            self.novel.locations[lcId].from_xml(xmlLocation)
            self.novel.tree.append(LC_ROOT, lcId)

    def _read_plot_lines_and_points(self, root):
        xmlPlotLines = root.find('ARCS')
        if xmlPlotLines is None:
            return

        for xmlPlotLine in xmlPlotLines.iterfind('ARC'):
            plId = xmlPlotLine.attrib['id']
            self._check_id(plId, PLOT_LINE_PREFIX)
            self.novel.plotLines[plId] = PlotLine(on_element_change=self.on_element_change)
            self.novel.plotLines[plId].from_xml(xmlPlotLine)
            self.novel.tree.append(PL_ROOT, plId)

            self.novel.plotLines[plId].sections = intersection(self.novel.plotLines[plId].sections, self.novel.sections)

            for scId in self.novel.plotLines[plId].sections:
                self.novel.sections[scId].scPlotLines.append(plId)

            for xmlPlotPoint in xmlPlotLine.iterfind('POINT'):
                ppId = xmlPlotPoint.attrib['id']
                self._check_id(ppId, PLOT_POINT_PREFIX)
                self._read_plot_point(xmlPlotPoint, ppId, plId)
                self.novel.tree.append(plId, ppId)

    def _read_plot_point(self, xmlPlotPoint, ppId, plId):
        self.novel.plotPoints[ppId] = PlotPoint(on_element_change=self.on_element_change)
        self.novel.plotPoints[ppId].from_xml(xmlPlotPoint)

        scId = self.novel.plotPoints[ppId].sectionAssoc
        if scId in self.novel.sections:
            self.novel.sections[scId].scPlotPoints[ppId] = plId
        else:
            self.novel.plotPoints[ppId].sectionAssoc = None

    def _read_project(self, root):
        xmlProject = root.find('PROJECT')
        if xmlProject is None:
            return

        self.novel.from_xml(xmlProject)

    def _read_project_notes(self, root):
        xmlProjectNotes = root.find('PROJECTNOTES')
        if xmlProjectNotes is None:
            return

        for xmlProjectNote in xmlProjectNotes.iterfind('PROJECTNOTE'):
            pnId = xmlProjectNote.attrib['id']
            self._check_id(pnId, PRJ_NOTE_PREFIX)
            self.novel.projectNotes[pnId] = BasicElement()
            self.novel.projectNotes[pnId].from_xml(xmlProjectNote)
            self.novel.tree.append(PN_ROOT, pnId)

    def _read_section(self, xmlSection, scId):
        self.novel.sections[scId] = Section(on_element_change=self.on_element_change)
        self.novel.sections[scId].from_xml(xmlSection)

        self.novel.sections[scId].characters = intersection(self.novel.sections[scId].characters, self.novel.characters)
        self.novel.sections[scId].locations = intersection(self.novel.sections[scId].locations, self.novel.locations)
        self.novel.sections[scId].items = intersection(self.novel.sections[scId].items, self.novel.items)

    def _read_word_count_log(self, xmlRoot):
        xmlWclog = xmlRoot.find('PROGRESS')
        if xmlWclog is None:
            return

        for xmlWc in xmlWclog.iterfind('WC'):
            wcDate = verified_date(xmlWc.find('Date').text)
            wcCount = verified_int_string(xmlWc.find('Count').text)
            wcTotalCount = verified_int_string(xmlWc.find('WithUnused').text)
            if wcDate and wcCount and wcTotalCount:
                self.wcLog[wcDate] = [wcCount, wcTotalCount]

    def _update_word_count_log(self):
        if self.novel.saveWordCount:
            newCountInt, newTotalCountInt = self.count_words()
            newCount = str(newCountInt)
            newTotalCount = str(newTotalCountInt)
            todayIso = date.today().isoformat()
            self.wcLogUpdate[todayIso] = [newCount, newTotalCount]
            for wcDate in self.wcLogUpdate:
                self.wcLog[wcDate] = self.wcLogUpdate[wcDate]
        self.wcLogUpdate = {}

    def _write_element_tree(self, xmlProject):
        backedUp = False
        if os.path.isfile(xmlProject.filePath):
            try:
                os.replace(xmlProject.filePath, f'{xmlProject.filePath}.bak')
            except:
                raise Error(f'{_("Cannot overwrite file")}: "{norm_path(xmlProject.filePath)}".')
            else:
                backedUp = True
        try:
            xmlProject.xmlTree.write(xmlProject.filePath, xml_declaration=False, encoding='utf-8')
        except:
            if backedUp:
                os.replace(f'{xmlProject.filePath}.bak', xmlProject.filePath)
            raise Error(f'{_("Cannot write file")}: "{norm_path(xmlProject.filePath)}".')



class DataWriter(NovxFile):
    DESCRIPTION = _('novelibre XML data files')
    EXTENSION = '.xml'
    SUFFIX = DATA_SUFFIX

    XML_HEADER = '''<?xml version="1.0" encoding="utf-8"?>
'''

    def __init__(self, filePath, **kwargs):
        super().__init__(filePath, **kwargs)
        path, __ = os.path.splitext(filePath)
        self._dataFiles = dict(
            CHARACTERS=f'{path}_Characters.xml',
            LOCATIONS=f'{path}_Locations.xml',
            ITEMS=f'{path}_Items.xml',
            ARCS=f'{path}_Plotlines.xml',
        )

    def _postprocess_xml_file(self, filePath):
        '''Postprocess three xml files created by ElementTree.
        
        Positional argument:
            filePath: str -- not used by this method.
            
        Postprocess and write the xml data files.        
        Extends the superclass method.
        '''
        for xmlBranch in self._dataFiles:
            super()._postprocess_xml_file(self._dataFiles[xmlBranch])

    def _write_element_tree(self, xmlProject):
        for xmlBranch in self._dataFiles:
            elementSubtree = xmlProject.xmlTree.find(xmlBranch)
            elementTree = ET.ElementTree(elementSubtree)
            try:
                elementTree.write(self._dataFiles[xmlBranch], xml_declaration=False, encoding='utf-8')
            except(PermissionError):
                raise Error(f'{_("File is write protected")}: "{norm_path(self._dataFiles[xmlBranch])}".')



class ScapNote:
    Y_FACTOR = 100000
    plotLineColor = None
    locationColor = None
    itemColor = None
    majorCharaColor = None
    minorCharaColor = None

    def __init__(self):
        self.text = None
        self.isSection = None
        self.isPlotLine = None
        self.isPlotPoint = None
        self.isTag = None
        self.isNote = None
        self.isMajorChara = None
        self.isMinorChara = None
        self.isLocation = None
        self.isItem = None
        self.isDescription = None
        self.textColor = None
        self.connections = None
        self.pointTo = None
        self.position = None
        self.uid = None

    def parse_xml(self, xmlNote):

        def str_to_rgb(colorStr):
            try:
                red, green, blue = colorStr.split(' ')
                return float(red), float(green), float(blue)
            except(ValueError):
                return (0.0, 0.0, 0.0)

        def color_matches(color1, color2):
            TOLERANCE = 0.1
            c1 = str_to_rgb(color1)
            c2 = str_to_rgb(color2)
            for i in range(3):
                if abs(c1[i] - c2[i]) > TOLERANCE:
                    return False

            return True

        self.isSection = False
        self.isPlotLine = False
        self.isPlotPoint = False
        self.isTag = False
        self.isNote = False
        self.isMajorChara = False
        self.isMinorChara = False
        self.isLocation = False
        self.isItem = False
        self.isDescription = False
        self.textColor = ''
        self.text = xmlNote.find('String').text
        positionStr = xmlNote.attrib['Position'].split(',')
        self.position = float(positionStr[1]) * self.Y_FACTOR + float(positionStr[0])

        scappId = xmlNote.attrib['ID']
        self.uid = str(int(scappId) + 1)
        appearance = xmlNote.find('Appearance')

        color = appearance.find('TextColor')
        if color is not None:
            self.textColor = color.text

        border = appearance.find('Border')
        if border is not None:
            borderStyle = border.attrib.get('Style', '')
            borderWeight = border.attrib.get('Weight', '0')
        else:
            borderStyle = ''
            borderWeight = '0'

        if 'Shadow' in xmlNote.attrib:
            self.isSection = True
        elif borderStyle == 'Square':
            self.isTag = True
        elif borderStyle == 'Cloud':
            self.isNote = True
        elif color_matches(self.textColor, self.plotLineColor):
            if borderWeight == '0':
                self.isPlotPoint = True
            else:
                self.isPlotLine = True
        elif color_matches(self.textColor, self.majorCharaColor):
            self.isMajorChara = True
        elif color_matches(self.textColor, self.minorCharaColor):
            self.isMinorChara = True
        elif color_matches(self.textColor, self.locationColor):
            self.isLocation = True
        elif color_matches(self.textColor, self.itemColor):
            self.isItem = True
        elif borderWeight == '0':
            self.isDescription = True

        self.connections = []
        if xmlNote.find('ConnectedNoteIDs') is not None:
            connGroups = xmlNote.find('ConnectedNoteIDs').text.split(', ')
            for connText in connGroups:
                if '-' in connText:
                    conns = connText.split('-')
                    start = int(conns[0]) + 1
                    end = int(conns[1]) + 2
                    for i in range(start, end):
                        self.connections.append(str(i))
                else:
                    i = int(connText) + 1
                    self.connections.append(str(i))

        self.pointTo = []
        if xmlNote.find('PointsToNoteIDs') is not None:
            pointGroups = xmlNote.find('PointsToNoteIDs').text.split(', ')
            for pointText in pointGroups:
                if '-' in pointText:
                    points = pointText.split('-')
                    start = int(points[0]) + 1
                    end = int(points[1]) + 2
                    for i in range(start, end):
                        self.pointTo.append(str(i))
                else:
                    i = int(pointText) + 1
                    self.pointTo.append(str(i))


class ScapFile(NovxFile):
    EXTENSION = '.scap'
    DESCRIPTION = 'Scapple diagram'
    SUFFIX = ''

    def __init__(self, filePath, **kwargs):
        ScapNote.locationColor = kwargs['location_color']
        ScapNote.plotLineColor = kwargs['plot_line_color']
        ScapNote.itemColor = kwargs['item_color']
        ScapNote.majorCharaColor = kwargs['major_chara_color']
        ScapNote.minorCharaColor = kwargs['minor_chara_color']
        super().__init__(filePath, **kwargs)
        self._exportSections = kwargs['export_sections']
        self._exportCharacters = kwargs['export_characters']
        self._exportLocations = kwargs['export_locations']
        self._exportItems = kwargs['export_items']
        self._exportPlotLines = kwargs['export_plot_lines']

    def read(self):

        def create_novel_element(note):

            if note.isSection:
                if not self._exportSections:
                    return

                scId = f'{SECTION_PREFIX}{note.uid}'
                self.novel.sections[scId] = Section(scene=0)
                self.novel.sections[scId].title = note.text.strip()
                self.novel.sections[scId].scType = 0
                self.novel.sections[scId].status = 1
                self.novel.sections[scId].sectionContent = '<p></p>'
                return

            if note.isPlotLine:
                if not self._exportPlotLines:
                    return

                plId = f'{PLOT_LINE_PREFIX}{note.uid}'
                self.novel.plotLines[plId] = PlotLine()
                plotLineTitle = note.text.strip().split(':', maxsplit=1)
                if len(plotLineTitle) > 1:
                    self.novel.plotLines[plId].shortName = plotLineTitle[0].strip()
                    self.novel.plotLines[plId].title = plotLineTitle[1].strip()
                else:
                    self.novel.plotLines[plId].shortName = plotLineTitle[0][0]
                    self.novel.plotLines[plId].title = plotLineTitle[0]
                self.novel.tree.append(PL_ROOT, plId)
                return

            if note.isPlotPoint:
                if not self._exportPlotLines:
                    return

                ppId = f'{PLOT_POINT_PREFIX}{note.uid}'
                self.novel.plotPoints[ppId] = PlotPoint()
                self.novel.plotPoints[ppId].title = note.text.strip()
                return

            if note.isMajorChara:
                if not self._exportCharacters:
                    return

                crId = f'{CHARACTER_PREFIX}{note.uid}'
                self.novel.characters[crId] = Character()
                self.novel.characters[crId].title = note.text.strip()
                self.novel.characters[crId].fullName = note.text.strip()
                self.novel.characters[crId].isMajor = True
                self.novel.tree.append(CR_ROOT, crId)
                return

            if note.isMinorChara:
                if not self._exportCharacters:
                    return

                crId = f'{CHARACTER_PREFIX}{note.uid}'
                self.novel.characters[crId] = Character()
                self.novel.characters[crId].title = note.text.strip()
                self.novel.characters[crId].fullName = note.text.strip()
                self.novel.characters[crId].isMajor = False
                self.novel.tree.append(CR_ROOT, crId)
                return

            if note.isLocation:
                if not self._exportLocations:
                    return

                lcId = f'{LOCATION_PREFIX}{note.uid}'
                self.novel.locations[lcId] = WorldElement()
                self.novel.locations[lcId].title = note.text.strip()
                self.novel.tree.append(LC_ROOT, lcId)
                return

            if note.isItem:
                if not self._exportItems:
                    return

                itId = f'{ITEM_PREFIX}{note.uid}'
                self.novel.items[itId] = WorldElement()
                self.novel.items[itId].title = note.text.strip()
                self.novel.tree.append(IT_ROOT, itId)

        def set_description(elemId, elements):
            for uid in scapNotes[elemId[2:]].connections:
                if scapNotes[uid].isDescription:
                    elements[elemId].desc = scapNotes[uid].text.strip()
                    return

        def set_notes(elemId, elements):
            elementNotes = []
            for uid in scapNotes[elemId[2:]].connections:
                if scapNotes[uid].isNote:
                    elementNotes .append(scapNotes[uid].text)
            elements[elemId].notes = '\n'.join(elementNotes)

        def set_relationships(scId):

            def add_relationship(uid):

                plId = f'{PLOT_LINE_PREFIX}{uid}'
                if plId in self.novel.plotLines:
                    scPlotLines.append(plId)
                    return

                ppId = f'{PLOT_POINT_PREFIX}{uid}'
                if ppId in self.novel.plotPoints:
                    scPlotPoints.append(ppId)
                    return

                crId = f'{CHARACTER_PREFIX}{uid}'
                if crId in self.novel.characters:
                    if scId[2:] in scapNotes[uid].pointTo:
                        scCharacters.insert(0, crId)
                    else:
                        scCharacters.append(crId)
                    return

                lcId = f'{LOCATION_PREFIX}{uid}'
                if lcId in self.novel.locations:
                    scLocations.append(lcId)
                    return

                itId = f'{ITEM_PREFIX}{uid}'
                if itId in self.novel.items:
                    scItems.append(itId)
                    return

            scCharacters = []
            scLocations = []
            scItems = []
            scPlotLines = []
            scPlotPoints = []
            for uid in scapNotes[scId[2:]].connections:
                add_relationship(uid)
            self.novel.sections[scId].characters = scCharacters
            self.novel.sections[scId].locations = scLocations
            self.novel.sections[scId].items = scItems
            self.novel.sections[scId].plotLines = scPlotLines
            for ppId in scPlotPoints:
                plId = self.novel.tree.parent(ppId)
                self.novel.sections[scId].scPlotPoints[ppId] = plId
                self.novel.plotPoints[ppId].sectionAssoc = scId
                if not plId in scPlotLines:
                    scPlotLines.append(plId)
            for plId in scPlotLines:
                plSections = self.novel.plotLines[plId].sections
                if plSections is None:
                    plSections = []
                plSections.append(scId)
                self.novel.plotLines[plId].sections = plSections

        def set_tags(elemId, elements):
            elementTags = []
            for uid in scapNotes[elemId[2:]].connections:
                if scapNotes[uid].isTag:
                    elementTags.append(scapNotes[uid].text)
            elements[elemId].tags = elementTags

        self._tree = ET.parse(self.filePath)
        root = self._tree.getroot()

        chId = f'{CHAPTER_PREFIX}1'
        self.novel.chapters[chId] = Chapter(chLevel=2, chType=0)
        self.novel.chapters[chId].title = 'Chapter 1'
        self.novel.tree.append(CH_ROOT, chId)

        scapNotes = {}
        uidByPos = {}
        for xmlNote in root.iter('Note'):
            note = ScapNote()
            note.parse_xml(xmlNote)
            scapNotes[note.uid] = note
            uidByPos[note.position] = note.uid
            create_novel_element(note)

        srtNotes = sorted(uidByPos.items())
        for srtNote in srtNotes:
            scId = f'{SECTION_PREFIX}{srtNote[1]}'
            if scId in self.novel.sections:
                self.novel.tree.append(chId, scId)

        plotPoints = []
        for plId in self.novel.plotLines:
            for uid in scapNotes[plId[2:]].connections:
                if not scapNotes[uid].isPlotPoint:
                    continue

                ppId = f'{PLOT_POINT_PREFIX}{uid}'
                if ppId in plotPoints:
                    continue

                self.novel.tree.append(plId, ppId)
                plotPoints.append(ppId)
                searchNext = True
                while searchNext:
                    searchNext = False
                    for uid in scapNotes[ppId[2:]].connections:
                        if not scapNotes[uid].isPlotPoint:
                            continue

                        ppId = f'{PLOT_POINT_PREFIX}{uid}'
                        if ppId in plotPoints:
                            continue

                        self.novel.tree.append(plId, ppId)
                        plotPoints.append(ppId)
                        searchNext = True
                        break


        for scId in self.novel.sections:
            set_relationships(scId)
            set_description(scId, self.novel.sections)
            set_tags(scId, self.novel.sections)
            set_notes(scId, self.novel.sections)

        for crId in self.novel.characters:
            set_description(crId, self.novel.characters)
            set_tags(crId, self.novel.characters)
            set_notes(crId, self.novel.characters)

        for lcId in self.novel.locations:
            set_description(lcId, self.novel.locations)
            set_tags(lcId, self.novel.locations)
            set_notes(lcId, self.novel.locations)

        for itId in self.novel.items:
            set_description(itId, self.novel.items)
            set_tags(itId, self.novel.items)
            set_notes(itId, self.novel.items)

        for plId in self.novel.plotLines:
            set_description(plId, self.novel.plotLines)
            set_notes(plId, self.novel.plotLines)

        for ppId in self.novel.plotPoints:
            set_description(ppId, self.novel.plotPoints)
            set_notes(ppId, self.novel.plotPoints)

        self.novel.check_locale()

        return 'Scapple data converted to novel structure.'



class ScapConverter:

    def run(self, sourcePath, **kwargs):
        self.newFile = None

        if not os.path.isfile(sourcePath):
            self.ui.set_status(f'!File "{os.path.normpath(sourcePath)}" not found.')
            return
        fileName, fileExtension = os.path.splitext(sourcePath)
        if fileExtension == ScapFile.EXTENSION:
            if not os.path.isfile(f'{fileName}{NovxFile.EXTENSION}'):
                target = NovxFile(f'{fileName}{NovxFile.EXTENSION}', **kwargs)
            else:
                target = DataWriter(f'{fileName}{DataWriter.SUFFIX}{DataWriter.EXTENSION}', **kwargs)
            source = ScapFile(sourcePath, **kwargs)
            source.novel = Novel(tree=NvTree())
            source.read()
            target.novel = source.novel
            target.write()
        else:
            self.ui.set_status(f'!File type of "{os.path.normpath(sourcePath)}" not supported.')
        self.ui.set_status(f'{target.DESCRIPTION} successfully created.')


SUFFIX = ''
APPNAME = 'scap_novx'
GREEN = '0.0 0.5 0.0'
BLUE = '0.0 0.0 1.0'
RED = '1.0 0.0 0.0'
PURPLE = '0.5 0.0 0.5'
SAND = '0.6 0.2 0.0'
SETTINGS = dict(
    location_color=BLUE,
    item_color=GREEN,
    major_chara_color=RED,
    minor_chara_color=PURPLE,
    plot_line_color=SAND,
    )
OPTIONS = dict(
    export_sections=True,
    export_plot_lines=True,
    export_characters=True,
    export_locations=True,
    export_items=True,
    )


def main(sourcePath, silentMode=True, installDir='.'):
    if silentMode:
        ui = Ui('')
    else:
        ui = UiTk('Scapple to novelibre converter 5.3.0')

    sourceDir = os.path.dirname(sourcePath)
    if not sourceDir:
        sourceDir = '.'
    iniFileName = f'{APPNAME}.ini'
    iniFiles = [f'{installDir}/config/{iniFileName}', f'{sourceDir}/{iniFileName}']
    configuration = Configuration(SETTINGS, OPTIONS)
    for iniFile in iniFiles:
        configuration.read(iniFile)
    kwargs = {'suffix': SUFFIX}
    kwargs.update(configuration.settings)
    kwargs.update(configuration.options)
    converter = ScapConverter()
    converter.ui = ui
    converter.run(sourcePath, **kwargs)
    ui.start()


if __name__ == '__main__':
    silentMode = False
    sourcePath = ''
    if len(sys.argv) > 1:
        sourcePath = sys.argv[-1]
        silentMode = sys.argv[1] in ['--silent', '-s']
    else:
        print('usage: scap_novx.py [--silent] Sourcefile')
        sys.exit(1)
    try:
        homeDir = str(Path.home()).replace('\\', '/')
        installDir = f'{homeDir}/.novx/{APPNAME}/config'
    except:
        installDir = '.'
    main(sourcePath, silentMode, installDir)
